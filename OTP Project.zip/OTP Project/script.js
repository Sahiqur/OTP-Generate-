//Dom Element
const input_fields=document.getElementById("input-fields");
const verify=document.getElementById("verify");
const otp_Validation=document.getElementById("otp-Validation");
const clear=document.getElementById("clear");






let dynamicCode;
let ourOtp = "";

//functions
function inputOTP(e){
  const currentElement=e.target;
  const currentValue=e.target.value;
  const nextChild=currentElement.nextElementSibling;

  //checking value is number or not
  if(isNaN(currentValue)){
    currentElement.value="";
    return;
  }

  //forword to next child
  if(nextChild){
    nextChild.focus()
  }
  ourOtp=ourOtp+currentValue;
  
}

const GetOtp=document.getElementById("otp-Validation").innerHTML=Math.floor(1000 + Math.random() * 9000);
document.getElementById("otp-Validation").innerHTML="Your OTP Code is : "+GetOtp


function MatchOTP(e){
  inputOTP(e)
  const result=Number(ourOtp);
  if(result==GetOtp){
    document.getElementById("otp-generator").innerHTML="OTP has been Matched Successfully!!!";
  }else{
    document.getElementById("otp-generator").innerHTML="OTP Does Not Matched Successfully!!!";
  }

}

function ClearForm(){
  document.getElementById("myform").reset();
  document.getElementById("otp-Validation").innerHTML="Your OTP Code is : "+Math.floor(1000 + Math.random() * 9000);
  document.getElementById("otp-generator").innerHTML="Loading..."
  
}


//Event Listener

input_fields.addEventListener("input",inputOTP);
verify.addEventListener("click",MatchOTP);
clear.addEventListener("click",ClearForm);